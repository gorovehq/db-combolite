"""Backend adapter layer.

The GUI only ever talks to a `Backend`. `MockBackend` holds fake, mutable, in-memory
data so every view and edit works today. Fill in `NativeBackend` with real calls into
the C library (ctypes / cffi / a CPython extension) as the engine API settles.

Conventions the GUI relies on:
  * table_schema() rows start with (column_name, type, ...); column 0 of table rows is the primary key.
  * Raise BackendError("message") for user-facing failures (constraint violations etc.).
  * Unimplemented methods raise NotImplementedError; the GUI reports it, never crashes.
"""
from __future__ import annotations

import json
import math
import random
import re
import time
from dataclasses import dataclass, field
from enum import Enum


class Model(str, Enum):
    TABLE = "table"
    DOCUMENT = "document"
    VECTOR = "vector"
    LINK = "link"
    TIMESERIES = "timeseries"


# model -> (sidebar heading, singular label, symbolic icon)
MODEL_INFO = {
    Model.TABLE: ("TABLES", "Table", "x-office-spreadsheet-symbolic"),
    Model.DOCUMENT: ("DOCUMENT POOLS", "Document pool", "text-x-generic-symbolic"),
    Model.VECTOR: ("VECTOR COLLECTIONS", "Vector collection", "view-app-grid-symbolic"),
    Model.LINK: ("LINKS", "Link set", "insert-link-symbolic"),
    Model.TIMESERIES: ("TIME SERIES", "Time series", "document-open-recent-symbolic"),
}


@dataclass
class Store:
    name: str
    model: Model
    count: int
    size_bytes: int = 0
    meta: dict = field(default_factory=dict)


@dataclass
class Result:
    columns: list
    rows: list
    total: int | None = None
    elapsed_ms: float = 0.0
    message: str = ""


@dataclass
class DocHit:
    id: str
    title: str
    rev: int
    score: float | None = None


@dataclass
class Procedure:
    name: str
    params: list      # e.g. ["$year", "$lang"]
    body: str         # CMBQL text
    doc: str = ""


@dataclass
class VectorGraph:
    ids: list            # entry ids
    vectors: list        # list[list[float]], same order as ids
    edges: list          # list[(i, j)] index pairs from the neighbour graph


class BackendError(Exception):
    """User-facing error; the GUI shows the message in a toast."""


class Backend:
    name = "base"
    path: str | None = None

    @property
    def is_open(self) -> bool:
        return self.path is not None

    def _todo(self, what):
        raise NotImplementedError(f"{type(self).__name__}.{what} is not wired up yet")

    # lifecycle
    def open(self, path: str) -> None: self._todo("open")
    def create(self, path: str) -> None: self._todo("create")
    def close(self) -> None: self.path = None
    def file_info(self) -> dict: return {"Path": self.path or ""}
    def list_stores(self) -> list[Store]: return []

    # relational tables
    def table_schema(self, name: str) -> Result: self._todo("table_schema")
    def table_indexes(self, name: str) -> Result: self._todo("table_indexes")
    def table_rows(self, name: str, offset: int, limit: int, filter_text: str = "") -> Result: self._todo("table_rows")
    def table_insert(self, name: str, values: dict) -> object: self._todo("table_insert")        # -> new pk
    def table_update(self, name: str, pk, column: str, value) -> None: self._todo("table_update")
    def table_delete(self, name: str, pks: list) -> int: self._todo("table_delete")              # -> rows deleted

    # document pools
    def doc_list(self, pool: str, limit: int = 200) -> list[DocHit]: self._todo("doc_list")
    def fts_search(self, pool: str, query: str, limit: int = 50) -> list[DocHit]: self._todo("fts_search")
    def doc_revisions(self, pool: str, doc_id: str) -> list[int]: self._todo("doc_revisions")
    def doc_get(self, pool: str, doc_id: str, rev: int | None = None) -> dict: self._todo("doc_get")
    def doc_put(self, pool: str, doc_id: str, doc: dict) -> int: self._todo("doc_put")           # -> new rev
    def doc_create(self, pool: str, doc: dict) -> str: self._todo("doc_create")                  # -> new id
    def doc_delete(self, pool: str, doc_id: str) -> None: self._todo("doc_delete")

    # vector collections
    def vector_search(self, coll: str, query: str, k: int, approximate: bool = False) -> list[tuple[str, float]]:
        self._todo("vector_search")
    def vector_graph(self, coll: str, limit: int = 220) -> VectorGraph: self._todo("vector_graph")
    def vector_get(self, coll: str, vec_id: str) -> list[float]: self._todo("vector_get")
    def vector_put(self, coll: str, vec_id: str, vec: list[float]) -> None: self._todo("vector_put")
    def vector_delete(self, coll: str, vec_id: str) -> None: self._todo("vector_delete")

    # links
    def link_edges(self, name: str, limit: int = 500) -> Result: self._todo("link_edges")       # columns: source, target, ...
    def link_add(self, name: str, source: str, target: str, weight: float = 1.0) -> None: self._todo("link_add")
    def link_delete(self, name: str, pairs: list[tuple[str, str]]) -> int: self._todo("link_delete")

    # time series
    def ts_points(self, name: str, window_s: int) -> list[tuple[float, float]]: self._todo("ts_points")
    def ts_append(self, name: str, t: float, value: float) -> None: self._todo("ts_append")

    # query language (CMBQL)
    def execute(self, text: str) -> Result: self._todo("execute")

    # stored procedures
    def proc_list(self) -> list[Procedure]: self._todo("proc_list")
    def proc_save(self, proc: Procedure) -> None: self._todo("proc_save")
    def proc_delete(self, name: str) -> None: self._todo("proc_delete")


class NativeBackend(Backend):
    """Bridge to the real C99 library. Fill in each method against include/*.h.

    The engine never heap-allocates: allocate arena/page buffers here
    (ctypes.create_string_buffer) and keep them alive on self for the handle's lifetime.
    """

    name = "native"

    def __init__(self, lib_path: str):
        import ctypes
        self.ctypes = ctypes
        self.lib = ctypes.CDLL(lib_path)
        self.path = None
        self._db = None
        self._arena = None

    def open(self, path: str) -> None:
        # TODO: declare argtypes/restype, allocate self._arena, call the engine's open,
        # map non-zero return codes to BackendError(<engine message>), then self.path = path.
        self._todo("open")

    def create(self, path: str) -> None:
        self._todo("create")

    def close(self) -> None:
        # TODO: checkpoint + close the handle, then release buffers.
        self._db = None
        self._arena = None
        self.path = None


# ---------------------------------------------------------------- mock
_WORDS = ("river glass winter orchard lantern harbor cipher meadow ember north quiet "
          "iron silver garden letters voyage hollow tide").split()
_FIRST = "Ada Mary Jane Henry Edith Oscar Leo Virginia Walt Emily Arthur Louisa".split()
_LAST = "Shelley Austen James Wharton Wilde Tolstoy Woolf Whitman Bronte Doyle Alcott Hardy".split()


def _title(r: random.Random) -> str:
    words = " ".join(r.choice(_WORDS).capitalize() for _ in range(r.randint(2, 4)))
    return ("The " if r.random() < 0.4 else "") + words


def _cos_dist(a, b):
    dot = sum(x * y for x, y in zip(a, b))
    na = math.sqrt(sum(x * x for x in a)) or 1
    nb = math.sqrt(sum(y * y for y in b)) or 1
    return 1 - dot / (na * nb)


class MockBackend(Backend):
    """Deterministic, mutable fake data shaped like the GutenFree demo."""

    name = "mock"
    VEC_DIMS = 24
    _TABLES = {
        "books": (["id", "title", "author_id", "year", "lang", "downloads"],
                  ["INT", "TEXT", "INT", "INT", "TEXT", "INT"], 12480),
        "authors": (["id", "name", "born", "died"], ["INT", "TEXT", "INT", "INT"], 3120),
        "loans": (["id", "book_id", "reader", "started_at", "returned"],
                  ["INT", "INT", "TEXT", "TIMESTAMP", "BOOL"], 48213),
    }
    _DOC_POOLS = {"catalog": 9876, "reviews": 2210}
    _LINK_META = {
        "written_by": {"from": "books", "to": "authors", "cardinality": "n:1", "on_delete": "restrict"},
        "similar_to": {"from": "catalog", "to": "catalog", "cardinality": "n:m", "on_delete": "cascade"},
    }

    def __init__(self):
        self.path = None
        self._tables, self._revs, self._docs = {}, {}, {}
        self._doc_created, self._doc_deleted = {}, {}
        self._vec, self._vgraph = {}, {}
        self._links, self._ts_extra = {}, {}
        self._procs = {p.name: p for p in (
            Procedure("recent_books", ["$year"], "from books\nwhere year >= $year\norder by year desc\nlimit 50", "Books since a year"),
            Procedure("popular_by_lang", ["$lang", "$min"],
                      "from books\nwhere lang = $lang and downloads > $min\norder by downloads desc\nlimit 25", "Top downloads in a language"),
        )}

    def open(self, path): self.path = path
    def create(self, path): self.path = path

    def file_info(self):
        return {"Path": self.path, "Size": "18.4 MiB", "Page size": "4096 B", "Format": "v0 (unstable)",
                "Journal": "rollback · fsync on commit", "Last checkpoint": time.strftime("%Y-%m-%d %H:%M")}

    def list_stores(self):
        s = [Store(n, Model.TABLE, len(self._tables[n]) if n in self._tables else c)
             for n, (_, _, c) in self._TABLES.items()]
        for pool, n in self._DOC_POOLS.items():
            n += len(self._doc_created.get(pool, [])) - len(self._doc_deleted.get(pool, set()))
            s.append(Store(pool, Model.DOCUMENT, n, meta={"fts": "bm25"}))
        s.append(Store("book_embeddings", Model.VECTOR, len(self._vectors("book_embeddings")),
                       meta={"dims": self.VEC_DIMS, "metric": "cosine", "index": "neighbour graph"}))
        s.append(Store("title_vecs", Model.VECTOR, len(self._vectors("title_vecs")),
                       meta={"dims": self.VEC_DIMS, "metric": "cosine", "index": "exact"}))
        for name, meta in self._LINK_META.items():
            s.append(Store(name, Model.LINK, len(self._link_rows(name)), meta=meta))
        s.append(Store("reads_per_min", Model.TIMESERIES, 525600, meta={"unit": "reads/min", "late_arrival": "merge"}))
        s.append(Store("cache_hits", Model.TIMESERIES, 131400, meta={"unit": "%", "late_arrival": "reject"}))
        return s

    # ---- tables
    @staticmethod
    def _gen_row(table, r, rid):
        if table == "books":
            return (rid, _title(r), r.randint(1, 3120), r.randint(1600, 1925),
                    r.choice(["en", "en", "en", "fr", "de", "es"]), r.randint(0, 90000))
        if table == "authors":
            born = r.randint(1550, 1900)
            return (rid, f"{r.choice(_FIRST)} {r.choice(_LAST)}", born,
                    born + r.randint(25, 90) if r.random() > 0.05 else None)
        return (rid, r.randint(1, 12480), f"reader-{r.randint(1, 900):04d}",
                f"2026-{r.randint(1, 10):02d}-{r.randint(1, 28):02d} {r.randint(0, 23):02d}:{r.randint(0, 59):02d}",
                r.random() > 0.3)

    def _table(self, name):
        if name not in self._TABLES:
            raise BackendError(f"No table {name}")
        if name not in self._tables:
            r = random.Random(name)
            self._tables[name] = [self._gen_row(name, r, i + 1) for i in range(self._TABLES[name][2])]
        return self._tables[name]

    def table_schema(self, name):
        cols, types, _ = self._TABLES[name]
        rows = [(c, t, "NO" if c == "id" else "YES", None,
                 "PRIMARY KEY" if c == "id" else ("FOREIGN KEY" if c.endswith("_id") else ""))
                for c, t in zip(cols, types)]
        return Result(["column", "type", "nullable", "default", "constraints"], rows)

    def table_indexes(self, name):
        cols, _, _ = self._TABLES[name]
        rows = [(f"{name}_pkey", "id", "btree", True)]
        rows += [(f"{name}_{c}_idx", c, "btree", False) for c in cols if c.endswith("_id")]
        return Result(["index", "columns", "kind", "unique"], rows)

    def table_rows(self, name, offset, limit, filter_text=""):
        t = time.perf_counter()
        data = self._table(name)
        if filter_text:
            q = filter_text.lower()
            data = [row for row in data if any(q in str(v).lower() for v in row)]
        return Result(self._TABLES[name][0], data[offset:offset + limit], len(data), (time.perf_counter() - t) * 1000)

    def table_insert(self, name, values):
        cols = self._TABLES[name][0]
        data = self._table(name)
        pk = (max((r[0] for r in data), default=0)) + 1
        data.append(tuple(pk if c == "id" else values.get(c) for c in cols))
        return pk

    def table_update(self, name, pk, column, value):
        cols = self._TABLES[name][0]
        if column == "id":
            raise BackendError("Primary keys are immutable")
        i = cols.index(column)
        data = self._table(name)
        for n, row in enumerate(data):
            if row[0] == pk:
                data[n] = row[:i] + (value,) + row[i + 1:]
                return
        raise BackendError(f"Row {pk} no longer exists")

    def table_delete(self, name, pks):
        drop = set(pks)
        data = self._table(name)
        before = len(data)
        data[:] = [r for r in data if r[0] not in drop]
        return before - len(data)

    # ---- documents
    def _doc(self, pool, i):
        r = random.Random(f"{pool}:{i}")
        return DocHit(f"doc-{i + 1:05d}", _title(r), r.randint(1, 6))

    def _all_hits(self, pool, n):
        deleted = self._doc_deleted.get(pool, set())
        created = [DocHit(d, self.doc_get(pool, d).get("title", "Untitled"), self.doc_revisions(pool, d)[-1])
                   for d in reversed(self._doc_created.get(pool, []))]
        base = (self._doc(pool, i) for i in range(n))
        return [h for h in (*created, *base) if h.id not in deleted]

    def doc_list(self, pool, limit=200):
        return self._all_hits(pool, limit)[:limit]

    def fts_search(self, pool, query, limit=50):
        terms = query.lower().split()
        hits = []
        for d in self._all_hits(pool, 2000):
            s = sum(d.title.lower().count(w) for w in terms)
            if s:
                d.score = round(s * 2.1 + random.Random(d.id).random() * 1.5, 3)
                hits.append(d)
        return sorted(hits, key=lambda d: -d.score)[:limit]

    def doc_revisions(self, pool, doc_id):
        if doc_id in self._doc_deleted.get(pool, set()):
            raise BackendError(f"{doc_id} was deleted")
        base = self._revs.get((pool, doc_id)) or self._doc(pool, int(doc_id.split("-")[1]) - 1).rev
        return list(range(1, base + 1))

    def doc_get(self, pool, doc_id, rev=None):
        rev = rev or self.doc_revisions(pool, doc_id)[-1]
        if (pool, doc_id, rev) in self._docs:
            return self._docs[(pool, doc_id, rev)]
        i = int(doc_id.split("-")[1]) - 1
        r = random.Random(f"{pool}:{i}:{rev}")
        return {"_id": doc_id, "_rev": rev, "title": self._doc(pool, i).title,
                "author": f"{r.choice(_FIRST)} {r.choice(_LAST)}", "language": r.choice(["en", "fr", "de"]),
                "subjects": r.sample(_WORDS, 3), "downloads": r.randint(0, 90000),
                "excerpt": " ".join(r.choice(_WORDS) for _ in range(18)) + "."}

    def doc_put(self, pool, doc_id, doc):
        if not isinstance(doc, dict):
            raise BackendError("A document must be a JSON object")
        n = self.doc_revisions(pool, doc_id)[-1] + 1
        self._revs[(pool, doc_id)] = n
        self._docs[(pool, doc_id, n)] = {**doc, "_id": doc_id, "_rev": n}
        return n

    def doc_create(self, pool, doc):
        n = self._DOC_POOLS[pool] + len(self._doc_created.get(pool, [])) + 1
        doc_id = f"doc-{n:05d}"
        self._revs[(pool, doc_id)] = 1
        self._docs[(pool, doc_id, 1)] = {**doc, "_id": doc_id, "_rev": 1}
        self._doc_created.setdefault(pool, []).append(doc_id)
        return doc_id

    def doc_delete(self, pool, doc_id):
        self._doc_deleted.setdefault(pool, set()).add(doc_id)

    # ---- vectors
    def _vectors(self, coll):
        if coll not in self._vec:
            r = random.Random(coll)
            centers = [[r.gauss(0, 1) for _ in range(self.VEC_DIMS)] for _ in range(6)]
            self._vec[coll] = {f"vec-{i + 1:05d}": [x + r.gauss(0, 0.45) for x in centers[i % 6]] for i in range(220)}
        return self._vec[coll]

    def _parse_query(self, coll, query):
        data = self._vectors(coll)
        q = query.strip()
        if not q:
            raise BackendError("Enter an entry id or a vector literal.")
        if q.startswith("["):
            try:
                vec = [float(x) for x in json.loads(q)]
            except (ValueError, TypeError):
                raise BackendError("Vector literal must be a JSON array of numbers")
            return None, (vec + [0.0] * self.VEC_DIMS)[:self.VEC_DIMS]
        if q not in data:
            raise BackendError(f"No entry {q} in {coll}")
        return q, data[q]

    def vector_search(self, coll, query, k, approximate=False):
        qid, vec = self._parse_query(coll, query)
        scored = sorted((_cos_dist(vec, v), vid) for vid, v in self._vectors(coll).items() if vid != qid)
        return [(vid, round(d, 4)) for d, vid in scored[:k]]

    def vector_graph(self, coll, limit=220):
        if coll not in self._vgraph:
            data = self._vectors(coll)
            ids = list(data)[:limit]
            vecs = [data[i] for i in ids]
            edges = set()
            for i, a in enumerate(vecs):
                near = sorted(range(len(vecs)), key=lambda j: _cos_dist(a, vecs[j]) if j != i else 9)[:3]
                edges.update((min(i, j), max(i, j)) for j in near)
            self._vgraph[coll] = VectorGraph(ids, vecs, sorted(edges))
        return self._vgraph[coll]

    def vector_get(self, coll, vec_id):
        return self._parse_query(coll, vec_id)[1]

    def vector_put(self, coll, vec_id, vec):
        if len(vec) != self.VEC_DIMS:
            raise BackendError(f"{coll} expects {self.VEC_DIMS} dimensions, got {len(vec)}")
        self._vectors(coll)[vec_id] = list(vec)
        self._vgraph.pop(coll, None)

    def vector_delete(self, coll, vec_id):
        if self._vectors(coll).pop(vec_id, None) is None:
            raise BackendError(f"No entry {vec_id}")
        self._vgraph.pop(coll, None)

    # ---- links
    def _link_rows(self, name):
        if name not in self._links:
            r = random.Random(name)
            date = lambda: f"2026-{r.randint(1, 10):02d}-{r.randint(1, 28):02d}"
            rows = []
            if name == "written_by":
                rows = [(f"book-{b:05d}", f"author-{r.randint(1, 45):04d}", date(), round(r.uniform(0.2, 1.0), 3)) for b in range(1, 181)]
            else:
                seen = set()
                for _ in range(260):
                    c = r.randint(0, 7)
                    a, b = c * 18 + r.randint(1, 18), c * 18 + r.randint(1, 18)
                    cross = r.random() < 0.08
                    if cross:
                        b = r.randint(1, 144)
                    if a != b and (a, b) not in seen:
                        seen.add((a, b))
                        rows.append((f"doc-{a:05d}", f"doc-{b:05d}", date(), round(r.uniform(0.05, 0.35) if cross else r.uniform(0.55, 1.0), 3)))
            self._links[name] = rows
        return self._links[name]

    def link_edges(self, name, limit=500):
        t = time.perf_counter()
        rows = self._link_rows(name)
        return Result(["source", "target", "created", "weight"], rows[:limit], len(rows), (time.perf_counter() - t) * 1000)

    def link_add(self, name, source, target, weight=1.0):
        source, target = source.strip(), target.strip()
        if not source or not target:
            raise BackendError("Source and target are required")
        rows = self._link_rows(name)
        if self._LINK_META[name]["cardinality"] == "n:1":
            for s, t, *_ in rows:
                if s == source:
                    raise BackendError(f"{name} is n:1 — {source} already links to {t}")
        if any(s == source and t == target for s, t, *_ in rows):
            raise BackendError("That link already exists")
        rows.insert(0, (source, target, time.strftime("%Y-%m-%d"), round(float(weight), 3)))

    def link_delete(self, name, pairs):
        drop = set(pairs)
        rows = self._link_rows(name)
        before = len(rows)
        rows[:] = [r for r in rows if (r[0], r[1]) not in drop]
        return before - len(rows)

    # ---- time series
    def ts_points(self, name, window_s):
        now, n = time.time(), 180
        r = random.Random(f"{name}:{window_s}")
        pts = []
        for i in range(n):
            t = now - window_s + window_s * i / (n - 1)
            base = 88 + 6 * math.sin(i / 20) if name == "cache_hits" else 60 + 25 * math.sin(i / 14) + 10 * math.sin(i / 5.3)
            pts.append((t, max(0.0, base + r.gauss(0, 4))))
        pts += [p for p in self._ts_extra.get(name, []) if now - window_s <= p[0] <= now + 3600]
        return sorted(pts)

    def ts_append(self, name, t, value):
        if name == "cache_hits" and t < time.time() - 3600:
            raise BackendError("cache_hits rejects late arrivals older than 1 h")
        self._ts_extra.setdefault(name, []).append((t, value))

    # ---- query
    def proc_list(self):
        return sorted(self._procs.values(), key=lambda p: p.name)

    def proc_save(self, proc):
        self._procs[proc.name] = proc

    def proc_delete(self, name):
        if self._procs.pop(name, None) is None:
            raise BackendError(f"No procedure {name}")

    def execute(self, text):
        m = re.match(r"\s*call\s+(\w+)", text, re.I)
        if m:
            p = self._procs.get(m.group(1))
            if not p:
                raise BackendError(f"No procedure named {m.group(1)}")
            res = self.execute(p.body)
            res.message = f"mock · call {p.name}"
            return res
        q = text.lower()
        for name in self._TABLES:
            if name in q:
                m = re.search(r"limit\s+(\d+)", q)
                res = self.table_rows(name, 0, min(int(m.group(1)) if m else 50, 1000))
                res.message = f"mock · scanned {name}"
                return res
        raise BackendError("CMBQL isn't implemented in the engine yet. The mock answers any "
                           "query that names a table, e.g.  from books limit 20")
